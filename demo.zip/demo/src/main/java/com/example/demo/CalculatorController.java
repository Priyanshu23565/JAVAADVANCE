package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CalculatorController {

    @GetMapping("/add")
    public String add(@RequestParam int num1, @RequestParam int num2) {
        int result = num1 + num2;
        return String.valueOf(result);
    }

    @GetMapping("/subtract")
    public String subtract(@RequestParam int num1, @RequestParam int num2) {
        int result = num1 - num2;
        return String.valueOf(result);
    }

    @GetMapping("/mul")
    public String multiply(@RequestParam int num1, @RequestParam int num2) {
        int result = num1 * num2;
        return String.valueOf(result);
    }

    @GetMapping("/name")
    public String name(@RequestParam String name) {
        return "The name is " + name;
    }
    @GetMapping("/age")
    public int age(@RequestParam int age){
        return age;
    }
    @GetMapping("/mobile")
    public int mobile(@RequestParam int mobile){
        return mobile;
    }
}
